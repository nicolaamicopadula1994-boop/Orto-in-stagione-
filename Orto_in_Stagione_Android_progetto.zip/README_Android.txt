ORTO IN STAGIONE — progetto Android (starter Capacitor)

REQUISITI
- PC Windows/macOS/Linux
- Node.js LTS
- Android Studio con Android SDK

PASSAGGI
1. Estrai lo ZIP sul PC.
2. Apri una finestra terminale nella cartella del progetto.
3. Esegui: npm install
4. Esegui: npx cap add android
5. Esegui: npx cap sync android
6. Esegui: npx cap open android
7. In Android Studio: configura SDK, prova su emulatore/dispositivo e risolvi eventuali avvisi.
8. Per il Play Store: Build > Generate Signed Bundle/APK > Android App Bundle (AAB).
   Crea e custodisci con attenzione la chiave di firma. Non condividerla.
9. Carica AAB su Google Play Console, completa scheda, privacy, dichiarazioni, test richiesti e invio alla revisione.

IDENTITÀ
- Nome: Orto in Stagione
- Application ID: it.ortoinstagione.app
- Web assets: www/
- Icona provvisoria SVG: www/assets/icon.svg

IMPORTANTE
Questo pacchetto è un progetto di partenza predisposto per Capacitor, non è un AAB/APK già compilato e non è ancora pronto per invio immediato.
Il prototipo usa dati iniziali e memorizzazione browser locale; verificare la persistenza in Android, testare tutte le schermate e migliorare accessibilità/privacy/compatibilità prima della pubblicazione.
