ORTO IN STAGIONE — PROGETTO ANDROID

Questo è un progetto iniziale Capacitor, non un APK già compilato.

Per creare un APK di prova:
- Segui BUILD_APK_DA_GITHUB.txt per ottenere una build automatica tramite GitHub Actions.

Per sviluppatori con Android Studio:
1. Estrai lo ZIP.
2. Installa Node.js e Android Studio.
3. Apri il terminale nella cartella del progetto.
4. Esegui: npm install
5. Esegui: npx cap add android
6. Esegui: npx cap sync android
7. Esegui: npx cap open android
8. Compila da Android Studio.

La build debug non è una release pronta per Play Store.
