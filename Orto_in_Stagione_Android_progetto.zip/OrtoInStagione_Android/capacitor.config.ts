import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'it.ortoinstagione.app',
  appName: 'Orto in Stagione',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
